package xyz.myfun;

//b4a??? 
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BA.*;
//
import java.net.InetAddress;
import java.net.UnknownHostException;

 
import java.net.Socket;

//
@Version(1.1f)
//@Permissions(values={"android.permission.INTERNET"})
@ShortName("xyzlib")
//@DependsOn(values={"some java library "})
//@ActivityObject

//public???
public  class xyzlib01 {

    public static void main(String[] args) {
        System.out.println("Hello World"); // 输出 Hello World
    }

    public static void show() {
        System.out.println("Hello World"); // 输出 Hello World
    }
	
	
	public int add(int x, int y) {
		return x + y;
	}	
	
    public String GetIP(String  s1) {
        InetAddress address = null;
        try {
            address = InetAddress.getByName(s1);
        }
        catch (UnknownHostException e) {
            //System.exit(2);
			BA.Log("java code==>"+"error");
			
			return "";
        }
		
		BA.Log("jjava code==>"+address.getHostName() + "=" + address.getHostAddress());
        //System.out.println(address.getHostName() + "=" + address.getHostAddress());
        //System.exit(0);
		
		return address.getHostAddress();
    }	
 

 
 
    public String WebPing(String  s1) {
        try {
            InetAddress addr;
            Socket sock = new Socket(s1, 80);
            addr = sock.getInetAddress();
           
            sock.close();
			BA.Log("java code==>"+"ok");
			
			return "OK";
			
        } catch (java.io.IOException e) {
 
			BA.Log("java code==>"+"fail");
			return "fail";
        }
    }
}

  